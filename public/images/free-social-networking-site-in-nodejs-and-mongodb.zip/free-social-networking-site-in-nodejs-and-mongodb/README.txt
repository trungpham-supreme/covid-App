Hi.

Thank you for using the free version of Social Networking Site script developed in Node JS & Mongo DB.

Complete source code of this project is available for sale at just $50 and it has a lot more features than this free version. As you might have seen that the premium features were blurred. You can pay using one of the following methods:

1) Credit card (Payoneer's payment gateway)

NOTE: Don't worry if you do not have an account. Payoneer will create that for you. 

2) EasyPaisa (Pakistan only)
3) JazzCash (Pakistan only)

Kindly contact us to buy:
adnan-tech.com

Thank you.